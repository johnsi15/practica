Node CRUD
========

CRUD hecho con NodeJS + Express + CouchDB

Autor
=====

Samuel Burbano Ramos

Twitter: @iosamuel
