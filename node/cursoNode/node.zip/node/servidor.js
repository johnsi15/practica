var http = require("http");
var url = require("url");
  console.log("Servidor ON");
function iniciar(enrutar,manejador){
	function arrancarServer(requiere, response){
		var ruta = url.parse(requiere.url).pathname;
		enrutar(manejador,ruta);
		response.writeHead(200,{"Content-Type":"text/html"});
		response.write("Hola Mundo");
		response.end();
		console.log("Peticion yeah!");
	}
	http.createServer(arrancarServer).listen(3000);
}

exports.iniciar = iniciar;
