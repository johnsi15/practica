var server = require("./servidor");
var enrutador = require("./enrutador");
var peticiones = require("./peticiones");

var manejador = {}
manejador["/"] = peticiones.inicio;
manejador["/hola"] = peticiones.hola;

server.iniciar(enrutador.enrutar, manejador);