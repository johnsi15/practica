function inicio(){
	console.log("Hola soy inicio");
	return "Inicio";
}

function hola(){
	console.log("Hola soy hola");
	//return "Hola";
}

exports.inicio = inicio;
exports.hola = hola;