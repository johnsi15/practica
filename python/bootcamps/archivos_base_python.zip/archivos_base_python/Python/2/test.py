hola = ["cosa","casa"]
print(hola[2])
