texto = open("../documentos/hola.txt")

print(texto.read())
