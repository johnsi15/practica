edad = 44

if edad < 40:
    print("Tienes menos de 40 años")
else:
    print("Tienes mas de 40 años")
