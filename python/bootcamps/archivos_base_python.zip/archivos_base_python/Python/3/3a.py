agenda = ["Jose Vicente","54325435","Calle 2, Valencia"]

print(agenda[3])
