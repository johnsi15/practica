edad = 34
nombre = "Jose Vicente"
apellido = "Carratala"

edad2 = 25
miVerdaderaEdad = 34

##print("Mi nombre es")
##print(nombre)
##print("y tengo")
##print(edad)
##print("años")

print("Mi nombre es",nombre,"y tengo",edad,"años, y el doble de mi edad es",(edad*2),"años")

print("Mi nombre es %s" %nombre)

print("Mi nombre completo es %s %s y mi edad es %d y la mitad de mi edad es %d" %(nombre, apellido, edad, edad/2))
