print("Dime tu nombre")
nombre = input()

print("El nombre que has introducido es: ",nombre)

edad = input("Y ahora dime tu edad >")
edadnumero = int(edad)

print("Y el triple de tu edad es %d"%(edadnumero*3))
