##print('En el ejercicio anterior he dicho que mi nombre es \'Jose Vicente\'')
##
##print("Mi nombre es Jose Vicente \n \r y esto es otra linea")

print("Nombre \t\t Edad  \t\t Poblacion")
print("Jose Vicente\t 34\t\t Valencia")
print("Jaime\t\t 45\t\t Madrid")
print("Juan\t\t 23\t\t Barcelona")
print("Javier\t\t 56\t\t Bilbao")
