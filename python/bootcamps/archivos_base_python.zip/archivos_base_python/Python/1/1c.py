print(3 + 3 + 6 + 7 + 8)
print(10 - 5 -2 -3 -4)
print(25 * 5)
print(25 / 5)

print(8%3)

print(3 != 4)

print(3 == 5 or 3 == 4 or 5 == 6)


