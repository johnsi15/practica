# Tercer programa
# por Jose Vicente Carratala

print("Esta linea no debe ejecutarse")
print("Hola")
print("Esta linea no debe ejecutarse")
print("Hola")
print("Esta linea no debe ejecutarse")
print("Hola")
print("Esta linea no debe ejecutarse")
print("Hola")
print("Esta linea no debe ejecutarse")
print("Hola")
print("Esta linea no debe ejecutarse")
print("Hola")
