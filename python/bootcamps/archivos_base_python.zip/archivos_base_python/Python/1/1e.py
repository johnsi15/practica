print("Hola")

edad = 34

print("El triple de mi edad es ",(edad*3))

nombre = "Jose Vicente "

print("El triple de mi nombre es",(nombre*3))
