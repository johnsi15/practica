print("Yo soy una frase")
print('Yo soy otra frase')

print("Yo soy una tercera frase")

print("En el ejercicio anterior dije 'Hola Mundo' y funcionó correctamente")
print('En el ejercicio anterior dije "Hola Mundo" y funcionó correctamente')
